
# Econometrics Final Case Project
Jacci Ferrantino


```python
import statsmodels.api as sm
import statsmodels.stats as sms
from statsmodels.stats import outliers_influence as oi
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
```

# Background

This project is of an applied nature and uses data that are available in the data file Capstone-HousePrices. The
source of these data is Anglin and Gencay, “Semiparametric Estimation of a Hedonic Price Function”(Journal of
Applied Econometrics 11, 1996, pages 633-648). We consider the modeling and prediction of house prices. Data
are available for 546 observations of the following variables:

1. sell: Sale price of the house
2. • lot: Lot size of the property in square feet
3.  bdms: Number of bedrooms
4. • fb: Number of full bathrooms
5.  sty: Number of stories excluding basement
6. • drv: Dummy that is 1 if the house has a driveway and 0 otherwise
7. • rec: Dummy that is 1 if the house has a recreational room and 0 otherwise
8. • ffin: Dummy that is 1 if the house has a full finished basement and 0 otherwise
9. • ghw: Dummy that is 1 if the house uses gas for hot water heating and 0 otherwise
10.  ca: Dummy that is 1 if there is central air conditioning and 0 otherwise
11. • gar: Number of covered garage places
12. • reg: Dummy that is 1 if the house is located in a preferred neighborhood of the city and 0 otherwise
13. • obs: Observation number, needed in part (h)


```python
# Import data that will be used to construct confidence interval of population mean
df = pd.read_excel("test7.xls")
```


```python
print(df.head(2))
```

       obs   sell   lot  bdms  fb  sty  drv  rec  ffin  ghw  ca  gar  reg
    0    1  42000  5850     3   1    2    1    0     1    0   0    1    0
    1    2  38500  4000     2   1    1    1    0     0    0   0    0    0


# Questions

# (a) 
Consider a linear model where the sale price of a house is the dependent variable and the explanatory variables
are the other variables given above. Perform a test for linearity. What do you conclude based on the test
result?


```python
df.dropna()
model = sm.OLS.from_formula("sell ~ lot+bdms+fb+sty+drv+rec+ffin+ghw+ca+gar+reg", data=df)
res = model.fit()
print(res.summary())
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>          <td>sell</td>       <th>  R-squared:         </th> <td>   0.673</td> 
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.666</td> 
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   99.97</td> 
</tr>
<tr>
  <th>Date:</th>             <td>Mon, 30 Nov 2020</td> <th>  Prob (F-statistic):</th> <td>6.18e-122</td>
</tr>
<tr>
  <th>Time:</th>                 <td>23:24:12</td>     <th>  Log-Likelihood:    </th> <td> -6034.1</td> 
</tr>
<tr>
  <th>No. Observations:</th>      <td>   546</td>      <th>  AIC:               </th> <td>1.209e+04</td>
</tr>
<tr>
  <th>Df Residuals:</th>          <td>   534</td>      <th>  BIC:               </th> <td>1.214e+04</td>
</tr>
<tr>
  <th>Df Model:</th>              <td>    11</td>      <th>                     </th>     <td> </td>    
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>    
</tr>
</table>
<table class="simpletable">
<tr>
      <td></td>         <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>Intercept</th> <td>-4038.3504</td> <td> 3409.471</td> <td>   -1.184</td> <td> 0.237</td> <td>-1.07e+04</td> <td> 2659.271</td>
</tr>
<tr>
  <th>lot</th>       <td>    3.5463</td> <td>    0.350</td> <td>   10.124</td> <td> 0.000</td> <td>    2.858</td> <td>    4.234</td>
</tr>
<tr>
  <th>bdms</th>      <td> 1832.0035</td> <td> 1047.000</td> <td>    1.750</td> <td> 0.081</td> <td> -224.741</td> <td> 3888.748</td>
</tr>
<tr>
  <th>fb</th>        <td> 1.434e+04</td> <td> 1489.921</td> <td>    9.622</td> <td> 0.000</td> <td> 1.14e+04</td> <td> 1.73e+04</td>
</tr>
<tr>
  <th>sty</th>       <td> 6556.9457</td> <td>  925.290</td> <td>    7.086</td> <td> 0.000</td> <td> 4739.291</td> <td> 8374.600</td>
</tr>
<tr>
  <th>drv</th>       <td> 6687.7789</td> <td> 2045.246</td> <td>    3.270</td> <td> 0.001</td> <td> 2670.065</td> <td> 1.07e+04</td>
</tr>
<tr>
  <th>rec</th>       <td> 4511.2838</td> <td> 1899.958</td> <td>    2.374</td> <td> 0.018</td> <td>  778.976</td> <td> 8243.592</td>
</tr>
<tr>
  <th>ffin</th>      <td> 5452.3855</td> <td> 1588.024</td> <td>    3.433</td> <td> 0.001</td> <td> 2332.845</td> <td> 8571.926</td>
</tr>
<tr>
  <th>ghw</th>       <td> 1.283e+04</td> <td> 3217.597</td> <td>    3.988</td> <td> 0.000</td> <td> 6510.706</td> <td> 1.92e+04</td>
</tr>
<tr>
  <th>ca</th>        <td> 1.263e+04</td> <td> 1555.021</td> <td>    8.124</td> <td> 0.000</td> <td> 9578.182</td> <td> 1.57e+04</td>
</tr>
<tr>
  <th>gar</th>       <td> 4244.8290</td> <td>  840.544</td> <td>    5.050</td> <td> 0.000</td> <td> 2593.650</td> <td> 5896.008</td>
</tr>
<tr>
  <th>reg</th>       <td> 9369.5132</td> <td> 1669.091</td> <td>    5.614</td> <td> 0.000</td> <td> 6090.724</td> <td> 1.26e+04</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td>93.454</td> <th>  Durbin-Watson:     </th> <td>   1.604</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.000</td> <th>  Jarque-Bera (JB):  </th> <td> 247.620</td>
</tr>
<tr>
  <th>Skew:</th>          <td> 0.853</td> <th>  Prob(JB):          </th> <td>1.70e-54</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 5.824</td> <th>  Cond. No.          </th> <td>3.07e+04</td>
</tr>
</table><br/><br/>Warnings:<br/>[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.<br/>[2] The condition number is large, 3.07e+04. This might indicate that there are<br/>strong multicollinearity or other numerical problems.




```python
reset=oi.reset_ramsey(res, degree=2)
print(reset)
```

    <F test: F=array([[26.98603521]]), p=2.922110452788588e-07, df_denom=533, df_num=1>


### Conclusion:

The Durbin-Watson stat is used to test for autocorrelation. It is about 1.497. Usually, if the Durbin-Watson stat is between 1.5 and 2.5, it is a good sign that there is no autocorrelation. The Jarque-Bera test statistic is not significantly different than zero. This may indicate that our data does not have a normal distribution. The RESET test has an F-Test of approx 27 and a p-value of approx 0, indicating that the model may be misspecified. The R2 (percentage explained) of the model is about 67.3%.

# (b) 
Now consider a linear model where the log of the sale price of the house is the dependent variable and the explanatory variables are as before. Perform again the test for linearity. What do you conclude now?


```python
df["log_sell"]=np.log(df["sell"])
model2 = sm.OLS.from_formula("log_sell ~ lot+bdms+fb+sty+drv+rec+ffin+ghw+ca+gar+reg", data=df)
res2 = model2.fit()
print(res2.summary())
```

                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:               log_sell   R-squared:                       0.677
    Model:                            OLS   Adj. R-squared:                  0.670
    Method:                 Least Squares   F-statistic:                     101.6
    Date:                Mon, 30 Nov 2020   Prob (F-statistic):          3.67e-123
    Time:                        23:24:12   Log-Likelihood:                 73.873
    No. Observations:                 546   AIC:                            -123.7
    Df Residuals:                     534   BIC:                            -72.11
    Df Model:                          11                                         
    Covariance Type:            nonrobust                                         
    ==============================================================================
                     coef    std err          t      P>|t|      [0.025      0.975]
    ------------------------------------------------------------------------------
    Intercept     10.0256      0.047    212.210      0.000       9.933      10.118
    lot         5.057e-05   4.85e-06     10.418      0.000     4.1e-05    6.01e-05
    bdms           0.0340      0.015      2.345      0.019       0.006       0.063
    fb             0.1678      0.021      8.126      0.000       0.127       0.208
    sty            0.0923      0.013      7.197      0.000       0.067       0.117
    drv            0.1307      0.028      4.610      0.000       0.075       0.186
    rec            0.0735      0.026      2.792      0.005       0.022       0.125
    ffin           0.0994      0.022      4.517      0.000       0.056       0.143
    ghw            0.1784      0.045      4.000      0.000       0.091       0.266
    ca             0.1780      0.022      8.262      0.000       0.136       0.220
    gar            0.0508      0.012      4.358      0.000       0.028       0.074
    reg            0.1271      0.023      5.496      0.000       0.082       0.173
    ==============================================================================
    Omnibus:                        7.621   Durbin-Watson:                   1.510
    Prob(Omnibus):                  0.022   Jarque-Bera (JB):                8.443
    Skew:                          -0.199   Prob(JB):                       0.0147
    Kurtosis:                       3.461   Cond. No.                     3.07e+04
    ==============================================================================
    
    Warnings:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.
    [2] The condition number is large, 3.07e+04. This might indicate that there are
    strong multicollinearity or other numerical problems.



```python
reset2=oi.reset_ramsey(res2, degree=2)
print(reset2)
```

    <F test: F=array([[0.27031433]]), p=0.6033368567016177, df_denom=533, df_num=1>


### Conclusion:
Durbin-Watson stat is between 1.5 and 2.5, it is a good sign that there is no autocorrelation. The Jarque-Bera test statistic is not significantly different than zero. This may indicate that our data does not have a normal distribution. The RESET test has an F-Test of approx .27 and a p-value of approx 0.6033, indicating that the model may be correctly specified. The R2 (percentage explained) of the model is about 67.7%.


# (c)

Continue with the linear model from question (b). Estimate a model that includes both the lot size variable and its logarithm, as well as all other explanatory variables without transformation. What is your conclusion, should we include lot size itself or its logarithm? 


```python
df["log_lot"]=np.log(df["lot"])
model3 = sm.OLS.from_formula("log_sell ~ log_lot+lot+bdms+fb+sty+drv+rec+ffin+ghw+ca+gar+reg", data=df)
res3 = model3.fit()
print(res3.summary())
```

                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:               log_sell   R-squared:                       0.687
    Model:                            OLS   Adj. R-squared:                  0.680
    Method:                 Least Squares   F-statistic:                     97.51
    Date:                Mon, 30 Nov 2020   Prob (F-statistic):          6.43e-126
    Time:                        23:24:12   Log-Likelihood:                 82.843
    No. Observations:                 546   AIC:                            -139.7
    Df Residuals:                     533   BIC:                            -83.75
    Df Model:                          12                                         
    Covariance Type:            nonrobust                                         
    ==============================================================================
                     coef    std err          t      P>|t|      [0.025      0.975]
    ------------------------------------------------------------------------------
    Intercept      7.1505      0.683     10.469      0.000       5.809       8.492
    log_lot        0.3827      0.091      4.219      0.000       0.205       0.561
    lot         -1.49e-05   1.62e-05     -0.918      0.359   -4.68e-05     1.7e-05
    bdms           0.0349      0.014      2.442      0.015       0.007       0.063
    fb             0.1659      0.020      8.161      0.000       0.126       0.206
    sty            0.0912      0.013      7.224      0.000       0.066       0.116
    drv            0.1068      0.028      3.752      0.000       0.051       0.163
    rec            0.0547      0.026      2.078      0.038       0.003       0.106
    ffin           0.1052      0.022      4.848      0.000       0.063       0.148
    ghw            0.1791      0.044      4.079      0.000       0.093       0.265
    ca             0.1643      0.021      7.657      0.000       0.122       0.206
    gar            0.0483      0.011      4.203      0.000       0.026       0.071
    reg            0.1344      0.023      5.884      0.000       0.090       0.179
    ==============================================================================
    Omnibus:                        7.927   Durbin-Watson:                   1.525
    Prob(Omnibus):                  0.019   Jarque-Bera (JB):                9.364
    Skew:                          -0.180   Prob(JB):                      0.00926
    Kurtosis:                       3.531   Cond. No.                     4.27e+05
    ==============================================================================
    
    Warnings:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.
    [2] The condition number is large, 4.27e+05. This might indicate that there are
    strong multicollinearity or other numerical problems.



```python
reset3= oi.reset_ramsey(res3, degree=2)
print(reset3)
```

    <F test: F=array([[0.06769]]), p=0.7948309729185185, df_denom=532, df_num=1>



### Conclusion:
Durbin-Watson stat is between 1.5 and 2.5, it is a good sign that there is no autocorrelation. The Jarque-Bera test statistic is still not significantly different than zero. This may indicate that our data does not have a normal distribution. The RESET test has an F-Test of approx .067 and a p-value of approx 0.79483, indicating that the model may be correctly specified. This is larger than the previous models. The R2 (percentage explained) of the model is about 68.7%, also the highest of the models so far, indicating this model is the most relevant thus far and we should include its logarithm instead of lot itself.




# (d) 

Consider now a model where the log of the sale price of the house is the dependent variable and the explanatory variables are the log transformation of lot size, with all other explanatory variables as before. We now consider interaction effects of the log lot size with the other variables. Construct these interaction variables. How many are individually significant? 


```python
model4 = sm.OLS.from_formula("log_sell ~ log_lot+bdms+fb+sty+drv+rec+ffin+ghw+ca+gar+reg+log_lot*bdms+log_lot*fb+log_lot*sty+log_lot*drv+log_lot*rec+log_lot*ffin+log_lot*ghw+log_lot*ca+log_lot*gar+log_lot*reg", data=df)
res4 = model4.fit()
print(res4.summary())
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>        <td>log_sell</td>     <th>  R-squared:         </th> <td>   0.695</td> 
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.683</td> 
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   56.89</td> 
</tr>
<tr>
  <th>Date:</th>             <td>Mon, 30 Nov 2020</td> <th>  Prob (F-statistic):</th> <td>2.26e-120</td>
</tr>
<tr>
  <th>Time:</th>                 <td>23:24:13</td>     <th>  Log-Likelihood:    </th> <td>  89.971</td> 
</tr>
<tr>
  <th>No. Observations:</th>      <td>   546</td>      <th>  AIC:               </th> <td>  -135.9</td> 
</tr>
<tr>
  <th>Df Residuals:</th>          <td>   524</td>      <th>  BIC:               </th> <td>  -41.28</td> 
</tr>
<tr>
  <th>Df Model:</th>              <td>    21</td>      <th>                     </th>     <td> </td>    
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>    
</tr>
</table>
<table class="simpletable">
<tr>
        <td></td>          <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>Intercept</th>    <td>    8.9665</td> <td>    1.071</td> <td>    8.375</td> <td> 0.000</td> <td>    6.863</td> <td>   11.070</td>
</tr>
<tr>
  <th>log_lot</th>      <td>    0.1527</td> <td>    0.128</td> <td>    1.190</td> <td> 0.235</td> <td>   -0.099</td> <td>    0.405</td>
</tr>
<tr>
  <th>bdms</th>         <td>    0.0191</td> <td>    0.327</td> <td>    0.058</td> <td> 0.953</td> <td>   -0.623</td> <td>    0.661</td>
</tr>
<tr>
  <th>fb</th>           <td>   -0.3682</td> <td>    0.429</td> <td>   -0.858</td> <td> 0.391</td> <td>   -1.211</td> <td>    0.475</td>
</tr>
<tr>
  <th>sty</th>          <td>    0.4889</td> <td>    0.310</td> <td>    1.579</td> <td> 0.115</td> <td>   -0.120</td> <td>    1.097</td>
</tr>
<tr>
  <th>drv</th>          <td>   -1.4634</td> <td>    0.717</td> <td>   -2.040</td> <td> 0.042</td> <td>   -2.872</td> <td>   -0.054</td>
</tr>
<tr>
  <th>rec</th>          <td>    1.6740</td> <td>    0.656</td> <td>    2.552</td> <td> 0.011</td> <td>    0.385</td> <td>    2.963</td>
</tr>
<tr>
  <th>ffin</th>         <td>   -0.0318</td> <td>    0.446</td> <td>   -0.071</td> <td> 0.943</td> <td>   -0.907</td> <td>    0.843</td>
</tr>
<tr>
  <th>ghw</th>          <td>   -0.5059</td> <td>    0.903</td> <td>   -0.560</td> <td> 0.575</td> <td>   -2.279</td> <td>    1.268</td>
</tr>
<tr>
  <th>ca</th>           <td>   -0.3403</td> <td>    0.496</td> <td>   -0.686</td> <td> 0.493</td> <td>   -1.315</td> <td>    0.634</td>
</tr>
<tr>
  <th>gar</th>          <td>    0.4019</td> <td>    0.259</td> <td>    1.554</td> <td> 0.121</td> <td>   -0.106</td> <td>    0.910</td>
</tr>
<tr>
  <th>reg</th>          <td>    0.1185</td> <td>    0.480</td> <td>    0.247</td> <td> 0.805</td> <td>   -0.824</td> <td>    1.061</td>
</tr>
<tr>
  <th>log_lot:bdms</th> <td>    0.0021</td> <td>    0.039</td> <td>    0.054</td> <td> 0.957</td> <td>   -0.074</td> <td>    0.078</td>
</tr>
<tr>
  <th>log_lot:fb</th>   <td>    0.0620</td> <td>    0.050</td> <td>    1.237</td> <td> 0.217</td> <td>   -0.036</td> <td>    0.161</td>
</tr>
<tr>
  <th>log_lot:sty</th>  <td>   -0.0464</td> <td>    0.036</td> <td>   -1.290</td> <td> 0.198</td> <td>   -0.117</td> <td>    0.024</td>
</tr>
<tr>
  <th>log_lot:drv</th>  <td>    0.1915</td> <td>    0.087</td> <td>    2.193</td> <td> 0.029</td> <td>    0.020</td> <td>    0.363</td>
</tr>
<tr>
  <th>log_lot:rec</th>  <td>   -0.1885</td> <td>    0.076</td> <td>   -2.468</td> <td> 0.014</td> <td>   -0.338</td> <td>   -0.038</td>
</tr>
<tr>
  <th>log_lot:ffin</th> <td>    0.0159</td> <td>    0.053</td> <td>    0.301</td> <td> 0.763</td> <td>   -0.088</td> <td>    0.120</td>
</tr>
<tr>
  <th>log_lot:ghw</th>  <td>    0.0811</td> <td>    0.107</td> <td>    0.759</td> <td> 0.448</td> <td>   -0.129</td> <td>    0.291</td>
</tr>
<tr>
  <th>log_lot:ca</th>   <td>    0.0595</td> <td>    0.058</td> <td>    1.026</td> <td> 0.305</td> <td>   -0.054</td> <td>    0.174</td>
</tr>
<tr>
  <th>log_lot:gar</th>  <td>   -0.0414</td> <td>    0.030</td> <td>   -1.372</td> <td> 0.171</td> <td>   -0.101</td> <td>    0.018</td>
</tr>
<tr>
  <th>log_lot:reg</th>  <td>    0.0015</td> <td>    0.056</td> <td>    0.027</td> <td> 0.978</td> <td>   -0.108</td> <td>    0.112</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td> 7.141</td> <th>  Durbin-Watson:     </th> <td>   1.524</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.028</td> <th>  Jarque-Bera (JB):  </th> <td>   8.203</td>
</tr>
<tr>
  <th>Skew:</th>          <td>-0.173</td> <th>  Prob(JB):          </th> <td>  0.0165</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 3.491</td> <th>  Cond. No.          </th> <td>4.77e+03</td>
</tr>
</table><br/><br/>Warnings:<br/>[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.<br/>[2] The condition number is large, 4.77e+03. This might indicate that there are<br/>strong multicollinearity or other numerical problems.




```python
reset4= oi.reset_ramsey(res4, degree=2)
print(reset4)
```

    <F test: F=array([[0.01157078]]), p=0.9143799774375326, df_denom=523, df_num=1>


### Conclusion:
With the addition of the new interaction terms, the model seems to be performing better with a R2 of 69.5% and a RESET F-Test value of 0.0115. However, when looking at the individual t-stats and corresponding p-values of the coefficients, only the driveway and rec-room dummy variables (drv and rec) and their interaction terms (multiplied by the log of lot size) drv* log_lot and rec* log lot, are statistically significant.


# (e) 
Perform an F-test for the joint significance of the interaction effects from question (d).


```python
#restricted model
model5 = sm.OLS.from_formula("log_sell ~ log_lot+bdms+fb+sty+drv+rec+ffin+ghw+ca+gar+reg+log_lot*drv+log_lot*rec", data=df)
res5 = model5.fit()
prunt(res5.summary())
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>        <td>log_sell</td>     <th>  R-squared:         </th> <td>   0.692</td> 
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.684</td> 
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   91.79</td> 
</tr>
<tr>
  <th>Date:</th>             <td>Mon, 30 Nov 2020</td> <th>  Prob (F-statistic):</th> <td>1.32e-126</td>
</tr>
<tr>
  <th>Time:</th>                 <td>23:24:14</td>     <th>  Log-Likelihood:    </th> <td>  86.878</td> 
</tr>
<tr>
  <th>No. Observations:</th>      <td>   546</td>      <th>  AIC:               </th> <td>  -145.8</td> 
</tr>
<tr>
  <th>Df Residuals:</th>          <td>   532</td>      <th>  BIC:               </th> <td>  -85.52</td> 
</tr>
<tr>
  <th>Df Model:</th>              <td>    13</td>      <th>                     </th>     <td> </td>    
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>    
</tr>
</table>
<table class="simpletable">
<tr>
       <td></td>          <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>Intercept</th>   <td>    8.7419</td> <td>    0.629</td> <td>   13.906</td> <td> 0.000</td> <td>    7.507</td> <td>    9.977</td>
</tr>
<tr>
  <th>log_lot</th>     <td>    0.1791</td> <td>    0.077</td> <td>    2.323</td> <td> 0.021</td> <td>    0.028</td> <td>    0.330</td>
</tr>
<tr>
  <th>bdms</th>        <td>    0.0388</td> <td>    0.014</td> <td>    2.714</td> <td> 0.007</td> <td>    0.011</td> <td>    0.067</td>
</tr>
<tr>
  <th>fb</th>          <td>    0.1615</td> <td>    0.020</td> <td>    7.971</td> <td> 0.000</td> <td>    0.122</td> <td>    0.201</td>
</tr>
<tr>
  <th>sty</th>         <td>    0.0908</td> <td>    0.013</td> <td>    7.242</td> <td> 0.000</td> <td>    0.066</td> <td>    0.115</td>
</tr>
<tr>
  <th>drv</th>         <td>   -1.1900</td> <td>    0.665</td> <td>   -1.790</td> <td> 0.074</td> <td>   -2.496</td> <td>    0.116</td>
</tr>
<tr>
  <th>rec</th>         <td>    1.5025</td> <td>    0.626</td> <td>    2.402</td> <td> 0.017</td> <td>    0.274</td> <td>    2.731</td>
</tr>
<tr>
  <th>ffin</th>        <td>    0.1028</td> <td>    0.022</td> <td>    4.763</td> <td> 0.000</td> <td>    0.060</td> <td>    0.145</td>
</tr>
<tr>
  <th>ghw</th>         <td>    0.1845</td> <td>    0.044</td> <td>    4.223</td> <td> 0.000</td> <td>    0.099</td> <td>    0.270</td>
</tr>
<tr>
  <th>ca</th>          <td>    0.1653</td> <td>    0.021</td> <td>    7.792</td> <td> 0.000</td> <td>    0.124</td> <td>    0.207</td>
</tr>
<tr>
  <th>gar</th>         <td>    0.0469</td> <td>    0.011</td> <td>    4.107</td> <td> 0.000</td> <td>    0.024</td> <td>    0.069</td>
</tr>
<tr>
  <th>reg</th>         <td>    0.1326</td> <td>    0.023</td> <td>    5.880</td> <td> 0.000</td> <td>    0.088</td> <td>    0.177</td>
</tr>
<tr>
  <th>log_lot:drv</th> <td>    0.1594</td> <td>    0.081</td> <td>    1.962</td> <td> 0.050</td> <td>   -0.000</td> <td>    0.319</td>
</tr>
<tr>
  <th>log_lot:rec</th> <td>   -0.1683</td> <td>    0.073</td> <td>   -2.314</td> <td> 0.021</td> <td>   -0.311</td> <td>   -0.025</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td> 7.976</td> <th>  Durbin-Watson:     </th> <td>   1.526</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.019</td> <th>  Jarque-Bera (JB):  </th> <td>   9.237</td>
</tr>
<tr>
  <th>Skew:</th>          <td>-0.189</td> <th>  Prob(JB):          </th> <td> 0.00987</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 3.513</td> <th>  Cond. No.          </th> <td>1.23e+03</td>
</tr>
</table><br/><br/>Warnings:<br/>[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.<br/>[2] The condition number is large, 1.23e+03. This might indicate that there are<br/>strong multicollinearity or other numerical problems.




```python
#sum of squared residuals
ssr_unrestricted=res4.ssr
ssr_restricted=res5.ssr

f_testa=(ssr_restricted - ssr_unrestricted)/10
f_testb=ssr_unrestricted/524
f_test=f_testa/f_testb

print("F-Test for Joint Significance:",f_test,'with p>.05 indicates joint significance')
```

    F-Test for Joint Significance: 0.597096237277436 with p>.05 indicates joint significance


# (f) 
Now perform model specification on the interaction variables using the general-to-specific approach. (Only
eliminate the interaction effects.)




```python
ModelA=sm.OLS.from_formula("log_sell ~ log_lot+bdms+fb+sty+drv+rec+ffin+ghw+ca+gar+reg+log_lot*bdms+log_lot*fb+log_lot*sty+log_lot*drv+log_lot*rec+log_lot*ffin+log_lot*ghw+log_lot*ca+log_lot*gar+log_lot*reg", data=df)
res4 = model4.fit()
print(res4.summary())
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>        <td>log_sell</td>     <th>  R-squared:         </th> <td>   0.695</td> 
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.683</td> 
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   56.89</td> 
</tr>
<tr>
  <th>Date:</th>             <td>Mon, 30 Nov 2020</td> <th>  Prob (F-statistic):</th> <td>2.26e-120</td>
</tr>
<tr>
  <th>Time:</th>                 <td>23:24:14</td>     <th>  Log-Likelihood:    </th> <td>  89.971</td> 
</tr>
<tr>
  <th>No. Observations:</th>      <td>   546</td>      <th>  AIC:               </th> <td>  -135.9</td> 
</tr>
<tr>
  <th>Df Residuals:</th>          <td>   524</td>      <th>  BIC:               </th> <td>  -41.28</td> 
</tr>
<tr>
  <th>Df Model:</th>              <td>    21</td>      <th>                     </th>     <td> </td>    
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>    
</tr>
</table>
<table class="simpletable">
<tr>
        <td></td>          <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>Intercept</th>    <td>    8.9665</td> <td>    1.071</td> <td>    8.375</td> <td> 0.000</td> <td>    6.863</td> <td>   11.070</td>
</tr>
<tr>
  <th>log_lot</th>      <td>    0.1527</td> <td>    0.128</td> <td>    1.190</td> <td> 0.235</td> <td>   -0.099</td> <td>    0.405</td>
</tr>
<tr>
  <th>bdms</th>         <td>    0.0191</td> <td>    0.327</td> <td>    0.058</td> <td> 0.953</td> <td>   -0.623</td> <td>    0.661</td>
</tr>
<tr>
  <th>fb</th>           <td>   -0.3682</td> <td>    0.429</td> <td>   -0.858</td> <td> 0.391</td> <td>   -1.211</td> <td>    0.475</td>
</tr>
<tr>
  <th>sty</th>          <td>    0.4889</td> <td>    0.310</td> <td>    1.579</td> <td> 0.115</td> <td>   -0.120</td> <td>    1.097</td>
</tr>
<tr>
  <th>drv</th>          <td>   -1.4634</td> <td>    0.717</td> <td>   -2.040</td> <td> 0.042</td> <td>   -2.872</td> <td>   -0.054</td>
</tr>
<tr>
  <th>rec</th>          <td>    1.6740</td> <td>    0.656</td> <td>    2.552</td> <td> 0.011</td> <td>    0.385</td> <td>    2.963</td>
</tr>
<tr>
  <th>ffin</th>         <td>   -0.0318</td> <td>    0.446</td> <td>   -0.071</td> <td> 0.943</td> <td>   -0.907</td> <td>    0.843</td>
</tr>
<tr>
  <th>ghw</th>          <td>   -0.5059</td> <td>    0.903</td> <td>   -0.560</td> <td> 0.575</td> <td>   -2.279</td> <td>    1.268</td>
</tr>
<tr>
  <th>ca</th>           <td>   -0.3403</td> <td>    0.496</td> <td>   -0.686</td> <td> 0.493</td> <td>   -1.315</td> <td>    0.634</td>
</tr>
<tr>
  <th>gar</th>          <td>    0.4019</td> <td>    0.259</td> <td>    1.554</td> <td> 0.121</td> <td>   -0.106</td> <td>    0.910</td>
</tr>
<tr>
  <th>reg</th>          <td>    0.1185</td> <td>    0.480</td> <td>    0.247</td> <td> 0.805</td> <td>   -0.824</td> <td>    1.061</td>
</tr>
<tr>
  <th>log_lot:bdms</th> <td>    0.0021</td> <td>    0.039</td> <td>    0.054</td> <td> 0.957</td> <td>   -0.074</td> <td>    0.078</td>
</tr>
<tr>
  <th>log_lot:fb</th>   <td>    0.0620</td> <td>    0.050</td> <td>    1.237</td> <td> 0.217</td> <td>   -0.036</td> <td>    0.161</td>
</tr>
<tr>
  <th>log_lot:sty</th>  <td>   -0.0464</td> <td>    0.036</td> <td>   -1.290</td> <td> 0.198</td> <td>   -0.117</td> <td>    0.024</td>
</tr>
<tr>
  <th>log_lot:drv</th>  <td>    0.1915</td> <td>    0.087</td> <td>    2.193</td> <td> 0.029</td> <td>    0.020</td> <td>    0.363</td>
</tr>
<tr>
  <th>log_lot:rec</th>  <td>   -0.1885</td> <td>    0.076</td> <td>   -2.468</td> <td> 0.014</td> <td>   -0.338</td> <td>   -0.038</td>
</tr>
<tr>
  <th>log_lot:ffin</th> <td>    0.0159</td> <td>    0.053</td> <td>    0.301</td> <td> 0.763</td> <td>   -0.088</td> <td>    0.120</td>
</tr>
<tr>
  <th>log_lot:ghw</th>  <td>    0.0811</td> <td>    0.107</td> <td>    0.759</td> <td> 0.448</td> <td>   -0.129</td> <td>    0.291</td>
</tr>
<tr>
  <th>log_lot:ca</th>   <td>    0.0595</td> <td>    0.058</td> <td>    1.026</td> <td> 0.305</td> <td>   -0.054</td> <td>    0.174</td>
</tr>
<tr>
  <th>log_lot:gar</th>  <td>   -0.0414</td> <td>    0.030</td> <td>   -1.372</td> <td> 0.171</td> <td>   -0.101</td> <td>    0.018</td>
</tr>
<tr>
  <th>log_lot:reg</th>  <td>    0.0015</td> <td>    0.056</td> <td>    0.027</td> <td> 0.978</td> <td>   -0.108</td> <td>    0.112</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td> 7.141</td> <th>  Durbin-Watson:     </th> <td>   1.524</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.028</td> <th>  Jarque-Bera (JB):  </th> <td>   8.203</td>
</tr>
<tr>
  <th>Skew:</th>          <td>-0.173</td> <th>  Prob(JB):          </th> <td>  0.0165</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 3.491</td> <th>  Cond. No.          </th> <td>4.77e+03</td>
</tr>
</table><br/><br/>Warnings:<br/>[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.<br/>[2] The condition number is large, 4.77e+03. This might indicate that there are<br/>strong multicollinearity or other numerical problems.




```python
#log_lot*reg eliminated
modelb = sm.OLS.from_formula("log_sell ~ log_lot+bdms+fb+sty+drv+rec+ffin+ghw+ca+gar+reg+log_lot*bdms+log_lot*fb+log_lot*sty+log_lot*drv+log_lot*rec+log_lot*ffin+log_lot*ghw+log_lot*ca+log_lot*gar", data=df)
resb = modelb.fit()
print(resb.summary())
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>        <td>log_sell</td>     <th>  R-squared:         </th> <td>   0.695</td> 
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.683</td> 
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   59.85</td> 
</tr>
<tr>
  <th>Date:</th>             <td>Mon, 30 Nov 2020</td> <th>  Prob (F-statistic):</th> <td>2.88e-121</td>
</tr>
<tr>
  <th>Time:</th>                 <td>23:24:15</td>     <th>  Log-Likelihood:    </th> <td>  89.970</td> 
</tr>
<tr>
  <th>No. Observations:</th>      <td>   546</td>      <th>  AIC:               </th> <td>  -137.9</td> 
</tr>
<tr>
  <th>Df Residuals:</th>          <td>   525</td>      <th>  BIC:               </th> <td>  -47.59</td> 
</tr>
<tr>
  <th>Df Model:</th>              <td>    20</td>      <th>                     </th>     <td> </td>    
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>    
</tr>
</table>
<table class="simpletable">
<tr>
        <td></td>          <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>Intercept</th>    <td>    8.9679</td> <td>    1.068</td> <td>    8.394</td> <td> 0.000</td> <td>    6.869</td> <td>   11.067</td>
</tr>
<tr>
  <th>log_lot</th>      <td>    0.1525</td> <td>    0.128</td> <td>    1.191</td> <td> 0.234</td> <td>   -0.099</td> <td>    0.404</td>
</tr>
<tr>
  <th>bdms</th>         <td>    0.0195</td> <td>    0.326</td> <td>    0.060</td> <td> 0.952</td> <td>   -0.621</td> <td>    0.660</td>
</tr>
<tr>
  <th>fb</th>           <td>   -0.3677</td> <td>    0.428</td> <td>   -0.859</td> <td> 0.391</td> <td>   -1.209</td> <td>    0.474</td>
</tr>
<tr>
  <th>sty</th>          <td>    0.4872</td> <td>    0.303</td> <td>    1.607</td> <td> 0.109</td> <td>   -0.108</td> <td>    1.083</td>
</tr>
<tr>
  <th>drv</th>          <td>   -1.4679</td> <td>    0.697</td> <td>   -2.106</td> <td> 0.036</td> <td>   -2.837</td> <td>   -0.098</td>
</tr>
<tr>
  <th>rec</th>          <td>    1.6747</td> <td>    0.655</td> <td>    2.558</td> <td> 0.011</td> <td>    0.388</td> <td>    2.961</td>
</tr>
<tr>
  <th>ffin</th>         <td>   -0.0349</td> <td>    0.430</td> <td>   -0.081</td> <td> 0.935</td> <td>   -0.880</td> <td>    0.810</td>
</tr>
<tr>
  <th>ghw</th>          <td>   -0.5043</td> <td>    0.900</td> <td>   -0.560</td> <td> 0.575</td> <td>   -2.272</td> <td>    1.264</td>
</tr>
<tr>
  <th>ca</th>           <td>   -0.3395</td> <td>    0.495</td> <td>   -0.686</td> <td> 0.493</td> <td>   -1.312</td> <td>    0.633</td>
</tr>
<tr>
  <th>gar</th>          <td>    0.4023</td> <td>    0.258</td> <td>    1.560</td> <td> 0.119</td> <td>   -0.104</td> <td>    0.909</td>
</tr>
<tr>
  <th>reg</th>          <td>    0.1315</td> <td>    0.023</td> <td>    5.705</td> <td> 0.000</td> <td>    0.086</td> <td>    0.177</td>
</tr>
<tr>
  <th>log_lot:bdms</th> <td>    0.0020</td> <td>    0.039</td> <td>    0.052</td> <td> 0.958</td> <td>   -0.074</td> <td>    0.078</td>
</tr>
<tr>
  <th>log_lot:fb</th>   <td>    0.0620</td> <td>    0.050</td> <td>    1.238</td> <td> 0.216</td> <td>   -0.036</td> <td>    0.160</td>
</tr>
<tr>
  <th>log_lot:sty</th>  <td>   -0.0462</td> <td>    0.035</td> <td>   -1.312</td> <td> 0.190</td> <td>   -0.115</td> <td>    0.023</td>
</tr>
<tr>
  <th>log_lot:drv</th>  <td>    0.1921</td> <td>    0.085</td> <td>    2.259</td> <td> 0.024</td> <td>    0.025</td> <td>    0.359</td>
</tr>
<tr>
  <th>log_lot:rec</th>  <td>   -0.1885</td> <td>    0.076</td> <td>   -2.473</td> <td> 0.014</td> <td>   -0.338</td> <td>   -0.039</td>
</tr>
<tr>
  <th>log_lot:ffin</th> <td>    0.0163</td> <td>    0.051</td> <td>    0.319</td> <td> 0.750</td> <td>   -0.084</td> <td>    0.116</td>
</tr>
<tr>
  <th>log_lot:ghw</th>  <td>    0.0809</td> <td>    0.107</td> <td>    0.759</td> <td> 0.448</td> <td>   -0.128</td> <td>    0.290</td>
</tr>
<tr>
  <th>log_lot:ca</th>   <td>    0.0595</td> <td>    0.058</td> <td>    1.027</td> <td> 0.305</td> <td>   -0.054</td> <td>    0.173</td>
</tr>
<tr>
  <th>log_lot:gar</th>  <td>   -0.0414</td> <td>    0.030</td> <td>   -1.377</td> <td> 0.169</td> <td>   -0.100</td> <td>    0.018</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td> 7.117</td> <th>  Durbin-Watson:     </th> <td>   1.524</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.028</td> <th>  Jarque-Bera (JB):  </th> <td>   8.170</td>
</tr>
<tr>
  <th>Skew:</th>          <td>-0.172</td> <th>  Prob(JB):          </th> <td>  0.0168</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 3.490</td> <th>  Cond. No.          </th> <td>4.73e+03</td>
</tr>
</table><br/><br/>Warnings:<br/>[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.<br/>[2] The condition number is large, 4.73e+03. This might indicate that there are<br/>strong multicollinearity or other numerical problems.




```python
#log_lot*bdrms removed
modelc = sm.OLS.from_formula("log_sell ~ log_lot+bdms+fb+sty+drv+rec+ffin+ghw+ca+gar+reg+log_lot*fb+log_lot*sty+log_lot*drv+log_lot*rec+log_lot*ffin+log_lot*ghw+log_lot*ca+log_lot*gar", data=df)
resc = modelc.fit()
print(resc.summary())
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>        <td>log_sell</td>     <th>  R-squared:         </th> <td>   0.695</td> 
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.684</td> 
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   63.12</td> 
</tr>
<tr>
  <th>Date:</th>             <td>Mon, 30 Nov 2020</td> <th>  Prob (F-statistic):</th> <td>3.57e-122</td>
</tr>
<tr>
  <th>Time:</th>                 <td>23:24:15</td>     <th>  Log-Likelihood:    </th> <td>  89.969</td> 
</tr>
<tr>
  <th>No. Observations:</th>      <td>   546</td>      <th>  AIC:               </th> <td>  -139.9</td> 
</tr>
<tr>
  <th>Df Residuals:</th>          <td>   526</td>      <th>  BIC:               </th> <td>  -53.89</td> 
</tr>
<tr>
  <th>Df Model:</th>              <td>    19</td>      <th>                     </th>     <td> </td>    
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>    
</tr>
</table>
<table class="simpletable">
<tr>
        <td></td>          <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>Intercept</th>    <td>    8.9349</td> <td>    0.861</td> <td>   10.381</td> <td> 0.000</td> <td>    7.244</td> <td>   10.626</td>
</tr>
<tr>
  <th>log_lot</th>      <td>    0.1565</td> <td>    0.103</td> <td>    1.515</td> <td> 0.130</td> <td>   -0.046</td> <td>    0.359</td>
</tr>
<tr>
  <th>bdms</th>         <td>    0.0366</td> <td>    0.015</td> <td>    2.506</td> <td> 0.013</td> <td>    0.008</td> <td>    0.065</td>
</tr>
<tr>
  <th>fb</th>           <td>   -0.3775</td> <td>    0.386</td> <td>   -0.979</td> <td> 0.328</td> <td>   -1.135</td> <td>    0.380</td>
</tr>
<tr>
  <th>sty</th>          <td>    0.4820</td> <td>    0.286</td> <td>    1.685</td> <td> 0.093</td> <td>   -0.080</td> <td>    1.044</td>
</tr>
<tr>
  <th>drv</th>          <td>   -1.4625</td> <td>    0.689</td> <td>   -2.123</td> <td> 0.034</td> <td>   -2.816</td> <td>   -0.109</td>
</tr>
<tr>
  <th>rec</th>          <td>    1.6759</td> <td>    0.654</td> <td>    2.564</td> <td> 0.011</td> <td>    0.392</td> <td>    2.960</td>
</tr>
<tr>
  <th>ffin</th>         <td>   -0.0374</td> <td>    0.427</td> <td>   -0.088</td> <td> 0.930</td> <td>   -0.877</td> <td>    0.802</td>
</tr>
<tr>
  <th>ghw</th>          <td>   -0.5016</td> <td>    0.898</td> <td>   -0.559</td> <td> 0.577</td> <td>   -2.265</td> <td>    1.262</td>
</tr>
<tr>
  <th>ca</th>           <td>   -0.3387</td> <td>    0.494</td> <td>   -0.685</td> <td> 0.493</td> <td>   -1.309</td> <td>    0.632</td>
</tr>
<tr>
  <th>gar</th>          <td>    0.4010</td> <td>    0.257</td> <td>    1.563</td> <td> 0.119</td> <td>   -0.103</td> <td>    0.905</td>
</tr>
<tr>
  <th>reg</th>          <td>    0.1314</td> <td>    0.023</td> <td>    5.710</td> <td> 0.000</td> <td>    0.086</td> <td>    0.177</td>
</tr>
<tr>
  <th>log_lot:fb</th>   <td>    0.0631</td> <td>    0.045</td> <td>    1.405</td> <td> 0.161</td> <td>   -0.025</td> <td>    0.151</td>
</tr>
<tr>
  <th>log_lot:sty</th>  <td>   -0.0456</td> <td>    0.033</td> <td>   -1.372</td> <td> 0.171</td> <td>   -0.111</td> <td>    0.020</td>
</tr>
<tr>
  <th>log_lot:drv</th>  <td>    0.1914</td> <td>    0.084</td> <td>    2.277</td> <td> 0.023</td> <td>    0.026</td> <td>    0.357</td>
</tr>
<tr>
  <th>log_lot:rec</th>  <td>   -0.1887</td> <td>    0.076</td> <td>   -2.479</td> <td> 0.014</td> <td>   -0.338</td> <td>   -0.039</td>
</tr>
<tr>
  <th>log_lot:ffin</th> <td>    0.0166</td> <td>    0.051</td> <td>    0.328</td> <td> 0.743</td> <td>   -0.083</td> <td>    0.116</td>
</tr>
<tr>
  <th>log_lot:ghw</th>  <td>    0.0806</td> <td>    0.106</td> <td>    0.758</td> <td> 0.449</td> <td>   -0.128</td> <td>    0.289</td>
</tr>
<tr>
  <th>log_lot:ca</th>   <td>    0.0594</td> <td>    0.058</td> <td>    1.027</td> <td> 0.305</td> <td>   -0.054</td> <td>    0.173</td>
</tr>
<tr>
  <th>log_lot:gar</th>  <td>   -0.0413</td> <td>    0.030</td> <td>   -1.380</td> <td> 0.168</td> <td>   -0.100</td> <td>    0.017</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td> 7.132</td> <th>  Durbin-Watson:     </th> <td>   1.524</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.028</td> <th>  Jarque-Bera (JB):  </th> <td>   8.190</td>
</tr>
<tr>
  <th>Skew:</th>          <td>-0.173</td> <th>  Prob(JB):          </th> <td>  0.0167</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 3.491</td> <th>  Cond. No.          </th> <td>2.83e+03</td>
</tr>
</table><br/><br/>Warnings:<br/>[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.<br/>[2] The condition number is large, 2.83e+03. This might indicate that there are<br/>strong multicollinearity or other numerical problems.




```python
#log_lot*ffin removed
modelc = sm.OLS.from_formula("log_sell ~ log_lot+bdms+fb+sty+drv+rec+ffin+ghw+ca+gar+reg+log_lot*fb+log_lot*sty+log_lot*drv+log_lot*rec+log_lot*ghw+log_lot*ca+log_lot*gar", data=df)
resc = modelc.fit()
print(resc.summary())
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>        <td>log_sell</td>     <th>  R-squared:         </th> <td>   0.695</td> 
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.685</td> 
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   66.73</td> 
</tr>
<tr>
  <th>Date:</th>             <td>Mon, 30 Nov 2020</td> <th>  Prob (F-statistic):</th> <td>4.54e-123</td>
</tr>
<tr>
  <th>Time:</th>                 <td>23:24:16</td>     <th>  Log-Likelihood:    </th> <td>  89.913</td> 
</tr>
<tr>
  <th>No. Observations:</th>      <td>   546</td>      <th>  AIC:               </th> <td>  -141.8</td> 
</tr>
<tr>
  <th>Df Residuals:</th>          <td>   527</td>      <th>  BIC:               </th> <td>  -60.08</td> 
</tr>
<tr>
  <th>Df Model:</th>              <td>    18</td>      <th>                     </th>     <td> </td>    
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>    
</tr>
</table>
<table class="simpletable">
<tr>
       <td></td>          <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>Intercept</th>   <td>    8.8765</td> <td>    0.841</td> <td>   10.550</td> <td> 0.000</td> <td>    7.224</td> <td>   10.529</td>
</tr>
<tr>
  <th>log_lot</th>     <td>    0.1636</td> <td>    0.101</td> <td>    1.621</td> <td> 0.106</td> <td>   -0.035</td> <td>    0.362</td>
</tr>
<tr>
  <th>bdms</th>        <td>    0.0365</td> <td>    0.015</td> <td>    2.507</td> <td> 0.012</td> <td>    0.008</td> <td>    0.065</td>
</tr>
<tr>
  <th>fb</th>          <td>   -0.3819</td> <td>    0.385</td> <td>   -0.992</td> <td> 0.322</td> <td>   -1.138</td> <td>    0.375</td>
</tr>
<tr>
  <th>sty</th>         <td>    0.4885</td> <td>    0.285</td> <td>    1.713</td> <td> 0.087</td> <td>   -0.072</td> <td>    1.049</td>
</tr>
<tr>
  <th>drv</th>         <td>   -1.4502</td> <td>    0.687</td> <td>   -2.110</td> <td> 0.035</td> <td>   -2.801</td> <td>   -0.100</td>
</tr>
<tr>
  <th>rec</th>         <td>    1.6214</td> <td>    0.632</td> <td>    2.567</td> <td> 0.011</td> <td>    0.380</td> <td>    2.862</td>
</tr>
<tr>
  <th>ffin</th>        <td>    0.1023</td> <td>    0.022</td> <td>    4.691</td> <td> 0.000</td> <td>    0.059</td> <td>    0.145</td>
</tr>
<tr>
  <th>ghw</th>         <td>   -0.5160</td> <td>    0.896</td> <td>   -0.576</td> <td> 0.565</td> <td>   -2.276</td> <td>    1.244</td>
</tr>
<tr>
  <th>ca</th>          <td>   -0.3545</td> <td>    0.491</td> <td>   -0.722</td> <td> 0.471</td> <td>   -1.320</td> <td>    0.611</td>
</tr>
<tr>
  <th>gar</th>         <td>    0.4015</td> <td>    0.256</td> <td>    1.566</td> <td> 0.118</td> <td>   -0.102</td> <td>    0.905</td>
</tr>
<tr>
  <th>reg</th>         <td>    0.1323</td> <td>    0.023</td> <td>    5.786</td> <td> 0.000</td> <td>    0.087</td> <td>    0.177</td>
</tr>
<tr>
  <th>log_lot:fb</th>  <td>    0.0636</td> <td>    0.045</td> <td>    1.417</td> <td> 0.157</td> <td>   -0.025</td> <td>    0.152</td>
</tr>
<tr>
  <th>log_lot:sty</th> <td>   -0.0464</td> <td>    0.033</td> <td>   -1.403</td> <td> 0.161</td> <td>   -0.111</td> <td>    0.019</td>
</tr>
<tr>
  <th>log_lot:drv</th> <td>    0.1899</td> <td>    0.084</td> <td>    2.264</td> <td> 0.024</td> <td>    0.025</td> <td>    0.355</td>
</tr>
<tr>
  <th>log_lot:rec</th> <td>   -0.1822</td> <td>    0.073</td> <td>   -2.481</td> <td> 0.013</td> <td>   -0.326</td> <td>   -0.038</td>
</tr>
<tr>
  <th>log_lot:ghw</th> <td>    0.0825</td> <td>    0.106</td> <td>    0.778</td> <td> 0.437</td> <td>   -0.126</td> <td>    0.291</td>
</tr>
<tr>
  <th>log_lot:ca</th>  <td>    0.0612</td> <td>    0.057</td> <td>    1.066</td> <td> 0.287</td> <td>   -0.052</td> <td>    0.174</td>
</tr>
<tr>
  <th>log_lot:gar</th> <td>   -0.0413</td> <td>    0.030</td> <td>   -1.383</td> <td> 0.167</td> <td>   -0.100</td> <td>    0.017</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td> 7.017</td> <th>  Durbin-Watson:     </th> <td>   1.525</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.030</td> <th>  Jarque-Bera (JB):  </th> <td>   8.046</td>
</tr>
<tr>
  <th>Skew:</th>          <td>-0.170</td> <th>  Prob(JB):          </th> <td>  0.0179</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 3.487</td> <th>  Cond. No.          </th> <td>2.78e+03</td>
</tr>
</table><br/><br/>Warnings:<br/>[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.<br/>[2] The condition number is large, 2.78e+03. This might indicate that there are<br/>strong multicollinearity or other numerical problems.




```python
#log_lot*ghw removed
modeld = sm.OLS.from_formula("log_sell ~ log_lot+bdms+fb+sty+drv+rec+ffin+ghw+ca+gar+reg+log_lot*fb+log_lot*sty+log_lot*drv+log_lot*rec+log_lot*ca+log_lot*gar", data=df)
resd= modeld.fit()
print(resd.summary())
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>        <td>log_sell</td>     <th>  R-squared:         </th> <td>   0.695</td> 
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.685</td> 
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   70.67</td> 
</tr>
<tr>
  <th>Date:</th>             <td>Mon, 30 Nov 2020</td> <th>  Prob (F-statistic):</th> <td>7.16e-124</td>
</tr>
<tr>
  <th>Time:</th>                 <td>23:24:16</td>     <th>  Log-Likelihood:    </th> <td>  89.600</td> 
</tr>
<tr>
  <th>No. Observations:</th>      <td>   546</td>      <th>  AIC:               </th> <td>  -143.2</td> 
</tr>
<tr>
  <th>Df Residuals:</th>          <td>   528</td>      <th>  BIC:               </th> <td>  -65.75</td> 
</tr>
<tr>
  <th>Df Model:</th>              <td>    17</td>      <th>                     </th>     <td> </td>    
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>    
</tr>
</table>
<table class="simpletable">
<tr>
       <td></td>          <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>Intercept</th>   <td>    8.8086</td> <td>    0.836</td> <td>   10.530</td> <td> 0.000</td> <td>    7.165</td> <td>   10.452</td>
</tr>
<tr>
  <th>log_lot</th>     <td>    0.1716</td> <td>    0.100</td> <td>    1.710</td> <td> 0.088</td> <td>   -0.025</td> <td>    0.369</td>
</tr>
<tr>
  <th>bdms</th>        <td>    0.0366</td> <td>    0.015</td> <td>    2.513</td> <td> 0.012</td> <td>    0.008</td> <td>    0.065</td>
</tr>
<tr>
  <th>fb</th>          <td>   -0.3764</td> <td>    0.385</td> <td>   -0.978</td> <td> 0.329</td> <td>   -1.132</td> <td>    0.380</td>
</tr>
<tr>
  <th>sty</th>         <td>    0.4909</td> <td>    0.285</td> <td>    1.722</td> <td> 0.086</td> <td>   -0.069</td> <td>    1.051</td>
</tr>
<tr>
  <th>drv</th>         <td>   -1.4326</td> <td>    0.687</td> <td>   -2.086</td> <td> 0.037</td> <td>   -2.782</td> <td>   -0.083</td>
</tr>
<tr>
  <th>rec</th>         <td>    1.6306</td> <td>    0.631</td> <td>    2.583</td> <td> 0.010</td> <td>    0.390</td> <td>    2.871</td>
</tr>
<tr>
  <th>ffin</th>        <td>    0.1036</td> <td>    0.022</td> <td>    4.766</td> <td> 0.000</td> <td>    0.061</td> <td>    0.146</td>
</tr>
<tr>
  <th>ghw</th>         <td>    0.1799</td> <td>    0.044</td> <td>    4.098</td> <td> 0.000</td> <td>    0.094</td> <td>    0.266</td>
</tr>
<tr>
  <th>ca</th>          <td>   -0.3397</td> <td>    0.491</td> <td>   -0.692</td> <td> 0.489</td> <td>   -1.304</td> <td>    0.624</td>
</tr>
<tr>
  <th>gar</th>         <td>    0.3973</td> <td>    0.256</td> <td>    1.551</td> <td> 0.121</td> <td>   -0.106</td> <td>    0.900</td>
</tr>
<tr>
  <th>reg</th>         <td>    0.1311</td> <td>    0.023</td> <td>    5.750</td> <td> 0.000</td> <td>    0.086</td> <td>    0.176</td>
</tr>
<tr>
  <th>log_lot:fb</th>  <td>    0.0630</td> <td>    0.045</td> <td>    1.405</td> <td> 0.161</td> <td>   -0.025</td> <td>    0.151</td>
</tr>
<tr>
  <th>log_lot:sty</th> <td>   -0.0467</td> <td>    0.033</td> <td>   -1.412</td> <td> 0.159</td> <td>   -0.112</td> <td>    0.018</td>
</tr>
<tr>
  <th>log_lot:drv</th> <td>    0.1878</td> <td>    0.084</td> <td>    2.241</td> <td> 0.025</td> <td>    0.023</td> <td>    0.352</td>
</tr>
<tr>
  <th>log_lot:rec</th> <td>   -0.1832</td> <td>    0.073</td> <td>   -2.496</td> <td> 0.013</td> <td>   -0.327</td> <td>   -0.039</td>
</tr>
<tr>
  <th>log_lot:ca</th>  <td>    0.0593</td> <td>    0.057</td> <td>    1.034</td> <td> 0.302</td> <td>   -0.053</td> <td>    0.172</td>
</tr>
<tr>
  <th>log_lot:gar</th> <td>   -0.0408</td> <td>    0.030</td> <td>   -1.368</td> <td> 0.172</td> <td>   -0.099</td> <td>    0.018</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td> 7.161</td> <th>  Durbin-Watson:     </th> <td>   1.532</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.028</td> <th>  Jarque-Bera (JB):  </th> <td>   7.984</td>
</tr>
<tr>
  <th>Skew:</th>          <td>-0.186</td> <th>  Prob(JB):          </th> <td>  0.0185</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 3.462</td> <th>  Cond. No.          </th> <td>2.73e+03</td>
</tr>
</table><br/><br/>Warnings:<br/>[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.<br/>[2] The condition number is large, 2.73e+03. This might indicate that there are<br/>strong multicollinearity or other numerical problems.




```python
#log_lot*ca removed
modele = sm.OLS.from_formula("log_sell ~ log_lot+bdms+fb+sty+drv+rec+ffin+ghw+ca+gar+reg+log_lot*fb+log_lot*sty+log_lot*drv+log_lot*rec+log_lot*gar", data=df)
rese= modele.fit()
print(rese.summary())
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>        <td>log_sell</td>     <th>  R-squared:         </th> <td>   0.694</td> 
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.685</td> 
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   75.01</td> 
</tr>
<tr>
  <th>Date:</th>             <td>Mon, 30 Nov 2020</td> <th>  Prob (F-statistic):</th> <td>1.38e-124</td>
</tr>
<tr>
  <th>Time:</th>                 <td>23:24:16</td>     <th>  Log-Likelihood:    </th> <td>  89.048</td> 
</tr>
<tr>
  <th>No. Observations:</th>      <td>   546</td>      <th>  AIC:               </th> <td>  -144.1</td> 
</tr>
<tr>
  <th>Df Residuals:</th>          <td>   529</td>      <th>  BIC:               </th> <td>  -70.95</td> 
</tr>
<tr>
  <th>Df Model:</th>              <td>    16</td>      <th>                     </th>     <td> </td>    
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>    
</tr>
</table>
<table class="simpletable">
<tr>
       <td></td>          <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>Intercept</th>   <td>    8.7822</td> <td>    0.836</td> <td>   10.503</td> <td> 0.000</td> <td>    7.140</td> <td>   10.425</td>
</tr>
<tr>
  <th>log_lot</th>     <td>    0.1748</td> <td>    0.100</td> <td>    1.743</td> <td> 0.082</td> <td>   -0.022</td> <td>    0.372</td>
</tr>
<tr>
  <th>bdms</th>        <td>    0.0352</td> <td>    0.015</td> <td>    2.428</td> <td> 0.016</td> <td>    0.007</td> <td>    0.064</td>
</tr>
<tr>
  <th>fb</th>          <td>   -0.3803</td> <td>    0.385</td> <td>   -0.988</td> <td> 0.324</td> <td>   -1.136</td> <td>    0.376</td>
</tr>
<tr>
  <th>sty</th>         <td>    0.4720</td> <td>    0.285</td> <td>    1.659</td> <td> 0.098</td> <td>   -0.087</td> <td>    1.031</td>
</tr>
<tr>
  <th>drv</th>         <td>   -1.4286</td> <td>    0.687</td> <td>   -2.080</td> <td> 0.038</td> <td>   -2.778</td> <td>   -0.079</td>
</tr>
<tr>
  <th>rec</th>         <td>    1.5567</td> <td>    0.627</td> <td>    2.482</td> <td> 0.013</td> <td>    0.324</td> <td>    2.789</td>
</tr>
<tr>
  <th>ffin</th>        <td>    0.1034</td> <td>    0.022</td> <td>    4.756</td> <td> 0.000</td> <td>    0.061</td> <td>    0.146</td>
</tr>
<tr>
  <th>ghw</th>         <td>    0.1772</td> <td>    0.044</td> <td>    4.043</td> <td> 0.000</td> <td>    0.091</td> <td>    0.263</td>
</tr>
<tr>
  <th>ca</th>          <td>    0.1672</td> <td>    0.021</td> <td>    7.880</td> <td> 0.000</td> <td>    0.125</td> <td>    0.209</td>
</tr>
<tr>
  <th>gar</th>         <td>    0.3385</td> <td>    0.250</td> <td>    1.355</td> <td> 0.176</td> <td>   -0.152</td> <td>    0.829</td>
</tr>
<tr>
  <th>reg</th>         <td>    0.1330</td> <td>    0.023</td> <td>    5.848</td> <td> 0.000</td> <td>    0.088</td> <td>    0.178</td>
</tr>
<tr>
  <th>log_lot:fb</th>  <td>    0.0636</td> <td>    0.045</td> <td>    1.418</td> <td> 0.157</td> <td>   -0.025</td> <td>    0.152</td>
</tr>
<tr>
  <th>log_lot:sty</th> <td>   -0.0443</td> <td>    0.033</td> <td>   -1.344</td> <td> 0.180</td> <td>   -0.109</td> <td>    0.020</td>
</tr>
<tr>
  <th>log_lot:drv</th> <td>    0.1873</td> <td>    0.084</td> <td>    2.235</td> <td> 0.026</td> <td>    0.023</td> <td>    0.352</td>
</tr>
<tr>
  <th>log_lot:rec</th> <td>   -0.1746</td> <td>    0.073</td> <td>   -2.395</td> <td> 0.017</td> <td>   -0.318</td> <td>   -0.031</td>
</tr>
<tr>
  <th>log_lot:gar</th> <td>   -0.0339</td> <td>    0.029</td> <td>   -1.164</td> <td> 0.245</td> <td>   -0.091</td> <td>    0.023</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td> 6.946</td> <th>  Durbin-Watson:     </th> <td>   1.529</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.031</td> <th>  Jarque-Bera (JB):  </th> <td>   7.810</td>
</tr>
<tr>
  <th>Skew:</th>          <td>-0.177</td> <th>  Prob(JB):          </th> <td>  0.0201</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 3.467</td> <th>  Cond. No.          </th> <td>2.71e+03</td>
</tr>
</table><br/><br/>Warnings:<br/>[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.<br/>[2] The condition number is large, 2.71e+03. This might indicate that there are<br/>strong multicollinearity or other numerical problems.




```python
#log_lot*gar removed
modelf = sm.OLS.from_formula("log_sell ~ log_lot+bdms+fb+sty+drv+rec+ffin+ghw+ca+gar+reg+log_lot*fb+log_lot*sty+log_lot*drv+log_lot*rec", data=df)
resf= modelf.fit()
print(resf.summary())
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>        <td>log_sell</td>     <th>  R-squared:         </th> <td>   0.693</td> 
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.685</td> 
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   79.87</td> 
</tr>
<tr>
  <th>Date:</th>             <td>Mon, 30 Nov 2020</td> <th>  Prob (F-statistic):</th> <td>2.96e-125</td>
</tr>
<tr>
  <th>Time:</th>                 <td>23:24:17</td>     <th>  Log-Likelihood:    </th> <td>  88.350</td> 
</tr>
<tr>
  <th>No. Observations:</th>      <td>   546</td>      <th>  AIC:               </th> <td>  -144.7</td> 
</tr>
<tr>
  <th>Df Residuals:</th>          <td>   530</td>      <th>  BIC:               </th> <td>  -75.86</td> 
</tr>
<tr>
  <th>Df Model:</th>              <td>    15</td>      <th>                     </th>     <td> </td>    
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>    
</tr>
</table>
<table class="simpletable">
<tr>
       <td></td>          <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>Intercept</th>   <td>    8.7739</td> <td>    0.836</td> <td>   10.490</td> <td> 0.000</td> <td>    7.131</td> <td>   10.417</td>
</tr>
<tr>
  <th>log_lot</th>     <td>    0.1758</td> <td>    0.100</td> <td>    1.753</td> <td> 0.080</td> <td>   -0.021</td> <td>    0.373</td>
</tr>
<tr>
  <th>bdms</th>        <td>    0.0353</td> <td>    0.015</td> <td>    2.432</td> <td> 0.015</td> <td>    0.007</td> <td>    0.064</td>
</tr>
<tr>
  <th>fb</th>          <td>   -0.3402</td> <td>    0.383</td> <td>   -0.887</td> <td> 0.375</td> <td>   -1.093</td> <td>    0.413</td>
</tr>
<tr>
  <th>sty</th>         <td>    0.4682</td> <td>    0.285</td> <td>    1.645</td> <td> 0.101</td> <td>   -0.091</td> <td>    1.027</td>
</tr>
<tr>
  <th>drv</th>         <td>   -1.2369</td> <td>    0.667</td> <td>   -1.854</td> <td> 0.064</td> <td>   -2.547</td> <td>    0.073</td>
</tr>
<tr>
  <th>rec</th>         <td>    1.5141</td> <td>    0.626</td> <td>    2.417</td> <td> 0.016</td> <td>    0.283</td> <td>    2.745</td>
</tr>
<tr>
  <th>ffin</th>        <td>    0.1028</td> <td>    0.022</td> <td>    4.727</td> <td> 0.000</td> <td>    0.060</td> <td>    0.145</td>
</tr>
<tr>
  <th>ghw</th>         <td>    0.1800</td> <td>    0.044</td> <td>    4.112</td> <td> 0.000</td> <td>    0.094</td> <td>    0.266</td>
</tr>
<tr>
  <th>ca</th>          <td>    0.1670</td> <td>    0.021</td> <td>    7.869</td> <td> 0.000</td> <td>    0.125</td> <td>    0.209</td>
</tr>
<tr>
  <th>gar</th>         <td>    0.0480</td> <td>    0.011</td> <td>    4.200</td> <td> 0.000</td> <td>    0.026</td> <td>    0.070</td>
</tr>
<tr>
  <th>reg</th>         <td>    0.1299</td> <td>    0.023</td> <td>    5.750</td> <td> 0.000</td> <td>    0.086</td> <td>    0.174</td>
</tr>
<tr>
  <th>log_lot:fb</th>  <td>    0.0590</td> <td>    0.045</td> <td>    1.321</td> <td> 0.187</td> <td>   -0.029</td> <td>    0.147</td>
</tr>
<tr>
  <th>log_lot:sty</th> <td>   -0.0439</td> <td>    0.033</td> <td>   -1.331</td> <td> 0.184</td> <td>   -0.109</td> <td>    0.021</td>
</tr>
<tr>
  <th>log_lot:drv</th> <td>    0.1645</td> <td>    0.082</td> <td>    2.018</td> <td> 0.044</td> <td>    0.004</td> <td>    0.325</td>
</tr>
<tr>
  <th>log_lot:rec</th> <td>   -0.1694</td> <td>    0.073</td> <td>   -2.327</td> <td> 0.020</td> <td>   -0.312</td> <td>   -0.026</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td> 7.433</td> <th>  Durbin-Watson:     </th> <td>   1.523</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.024</td> <th>  Jarque-Bera (JB):  </th> <td>   8.418</td>
</tr>
<tr>
  <th>Skew:</th>          <td>-0.186</td> <th>  Prob(JB):          </th> <td>  0.0149</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 3.482</td> <th>  Cond. No.          </th> <td>2.60e+03</td>
</tr>
</table><br/><br/>Warnings:<br/>[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.<br/>[2] The condition number is large, 2.6e+03. This might indicate that there are<br/>strong multicollinearity or other numerical problems.




```python
#log_lot*fb removed
modelg = sm.OLS.from_formula("log_sell ~ log_lot+bdms+fb+sty+drv+rec+ffin+ghw+ca+gar+reg+log_lot*sty+log_lot*drv+log_lot*rec", data=df)
resg= modelg.fit()
print(resg.summary())
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>        <td>log_sell</td>     <th>  R-squared:         </th> <td>   0.692</td> 
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.684</td> 
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   85.33</td> 
</tr>
<tr>
  <th>Date:</th>             <td>Mon, 30 Nov 2020</td> <th>  Prob (F-statistic):</th> <td>7.43e-126</td>
</tr>
<tr>
  <th>Time:</th>                 <td>23:24:17</td>     <th>  Log-Likelihood:    </th> <td>  87.452</td> 
</tr>
<tr>
  <th>No. Observations:</th>      <td>   546</td>      <th>  AIC:               </th> <td>  -144.9</td> 
</tr>
<tr>
  <th>Df Residuals:</th>          <td>   531</td>      <th>  BIC:               </th> <td>  -80.37</td> 
</tr>
<tr>
  <th>Df Model:</th>              <td>    14</td>      <th>                     </th>     <td> </td>    
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>    
</tr>
</table>
<table class="simpletable">
<tr>
       <td></td>          <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>Intercept</th>   <td>    8.2985</td> <td>    0.755</td> <td>   10.984</td> <td> 0.000</td> <td>    6.814</td> <td>    9.783</td>
</tr>
<tr>
  <th>log_lot</th>     <td>    0.2309</td> <td>    0.091</td> <td>    2.529</td> <td> 0.012</td> <td>    0.052</td> <td>    0.410</td>
</tr>
<tr>
  <th>bdms</th>        <td>    0.0362</td> <td>    0.015</td> <td>    2.497</td> <td> 0.013</td> <td>    0.008</td> <td>    0.065</td>
</tr>
<tr>
  <th>fb</th>          <td>    0.1655</td> <td>    0.021</td> <td>    8.030</td> <td> 0.000</td> <td>    0.125</td> <td>    0.206</td>
</tr>
<tr>
  <th>sty</th>         <td>    0.3842</td> <td>    0.278</td> <td>    1.384</td> <td> 0.167</td> <td>   -0.161</td> <td>    0.930</td>
</tr>
<tr>
  <th>drv</th>         <td>   -1.2546</td> <td>    0.667</td> <td>   -1.880</td> <td> 0.061</td> <td>   -2.566</td> <td>    0.056</td>
</tr>
<tr>
  <th>rec</th>         <td>    1.4725</td> <td>    0.626</td> <td>    2.352</td> <td> 0.019</td> <td>    0.243</td> <td>    2.702</td>
</tr>
<tr>
  <th>ffin</th>        <td>    0.1004</td> <td>    0.022</td> <td>    4.631</td> <td> 0.000</td> <td>    0.058</td> <td>    0.143</td>
</tr>
<tr>
  <th>ghw</th>         <td>    0.1809</td> <td>    0.044</td> <td>    4.130</td> <td> 0.000</td> <td>    0.095</td> <td>    0.267</td>
</tr>
<tr>
  <th>ca</th>          <td>    0.1662</td> <td>    0.021</td> <td>    7.831</td> <td> 0.000</td> <td>    0.125</td> <td>    0.208</td>
</tr>
<tr>
  <th>gar</th>         <td>    0.0475</td> <td>    0.011</td> <td>    4.155</td> <td> 0.000</td> <td>    0.025</td> <td>    0.070</td>
</tr>
<tr>
  <th>reg</th>         <td>    0.1313</td> <td>    0.023</td> <td>    5.812</td> <td> 0.000</td> <td>    0.087</td> <td>    0.176</td>
</tr>
<tr>
  <th>log_lot:sty</th> <td>   -0.0340</td> <td>    0.032</td> <td>   -1.058</td> <td> 0.291</td> <td>   -0.097</td> <td>    0.029</td>
</tr>
<tr>
  <th>log_lot:drv</th> <td>    0.1669</td> <td>    0.082</td> <td>    2.047</td> <td> 0.041</td> <td>    0.007</td> <td>    0.327</td>
</tr>
<tr>
  <th>log_lot:rec</th> <td>   -0.1647</td> <td>    0.073</td> <td>   -2.263</td> <td> 0.024</td> <td>   -0.308</td> <td>   -0.022</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td> 8.037</td> <th>  Durbin-Watson:     </th> <td>   1.525</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.018</td> <th>  Jarque-Bera (JB):  </th> <td>   9.196</td>
</tr>
<tr>
  <th>Skew:</th>          <td>-0.195</td> <th>  Prob(JB):          </th> <td>  0.0101</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 3.501</td> <th>  Cond. No.          </th> <td>2.18e+03</td>
</tr>
</table><br/><br/>Warnings:<br/>[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.<br/>[2] The condition number is large, 2.18e+03. This might indicate that there are<br/>strong multicollinearity or other numerical problems.




```python
#log_lot*sty removed
modelh = sm.OLS.from_formula("log_sell ~ log_lot+bdms+fb+sty+drv+rec+ffin+ghw+ca+gar+reg+log_lot*drv+log_lot*rec", data=df)
resh= modelh.fit()
print(resh.summary())
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>        <td>log_sell</td>     <th>  R-squared:         </th> <td>   0.692</td> 
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.684</td> 
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   91.79</td> 
</tr>
<tr>
  <th>Date:</th>             <td>Mon, 30 Nov 2020</td> <th>  Prob (F-statistic):</th> <td>1.32e-126</td>
</tr>
<tr>
  <th>Time:</th>                 <td>23:24:17</td>     <th>  Log-Likelihood:    </th> <td>  86.878</td> 
</tr>
<tr>
  <th>No. Observations:</th>      <td>   546</td>      <th>  AIC:               </th> <td>  -145.8</td> 
</tr>
<tr>
  <th>Df Residuals:</th>          <td>   532</td>      <th>  BIC:               </th> <td>  -85.52</td> 
</tr>
<tr>
  <th>Df Model:</th>              <td>    13</td>      <th>                     </th>     <td> </td>    
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>    
</tr>
</table>
<table class="simpletable">
<tr>
       <td></td>          <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>Intercept</th>   <td>    8.7419</td> <td>    0.629</td> <td>   13.906</td> <td> 0.000</td> <td>    7.507</td> <td>    9.977</td>
</tr>
<tr>
  <th>log_lot</th>     <td>    0.1791</td> <td>    0.077</td> <td>    2.323</td> <td> 0.021</td> <td>    0.028</td> <td>    0.330</td>
</tr>
<tr>
  <th>bdms</th>        <td>    0.0388</td> <td>    0.014</td> <td>    2.714</td> <td> 0.007</td> <td>    0.011</td> <td>    0.067</td>
</tr>
<tr>
  <th>fb</th>          <td>    0.1615</td> <td>    0.020</td> <td>    7.971</td> <td> 0.000</td> <td>    0.122</td> <td>    0.201</td>
</tr>
<tr>
  <th>sty</th>         <td>    0.0908</td> <td>    0.013</td> <td>    7.242</td> <td> 0.000</td> <td>    0.066</td> <td>    0.115</td>
</tr>
<tr>
  <th>drv</th>         <td>   -1.1900</td> <td>    0.665</td> <td>   -1.790</td> <td> 0.074</td> <td>   -2.496</td> <td>    0.116</td>
</tr>
<tr>
  <th>rec</th>         <td>    1.5025</td> <td>    0.626</td> <td>    2.402</td> <td> 0.017</td> <td>    0.274</td> <td>    2.731</td>
</tr>
<tr>
  <th>ffin</th>        <td>    0.1028</td> <td>    0.022</td> <td>    4.763</td> <td> 0.000</td> <td>    0.060</td> <td>    0.145</td>
</tr>
<tr>
  <th>ghw</th>         <td>    0.1845</td> <td>    0.044</td> <td>    4.223</td> <td> 0.000</td> <td>    0.099</td> <td>    0.270</td>
</tr>
<tr>
  <th>ca</th>          <td>    0.1653</td> <td>    0.021</td> <td>    7.792</td> <td> 0.000</td> <td>    0.124</td> <td>    0.207</td>
</tr>
<tr>
  <th>gar</th>         <td>    0.0469</td> <td>    0.011</td> <td>    4.107</td> <td> 0.000</td> <td>    0.024</td> <td>    0.069</td>
</tr>
<tr>
  <th>reg</th>         <td>    0.1326</td> <td>    0.023</td> <td>    5.880</td> <td> 0.000</td> <td>    0.088</td> <td>    0.177</td>
</tr>
<tr>
  <th>log_lot:drv</th> <td>    0.1594</td> <td>    0.081</td> <td>    1.962</td> <td> 0.050</td> <td>   -0.000</td> <td>    0.319</td>
</tr>
<tr>
  <th>log_lot:rec</th> <td>   -0.1683</td> <td>    0.073</td> <td>   -2.314</td> <td> 0.021</td> <td>   -0.311</td> <td>   -0.025</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td> 7.976</td> <th>  Durbin-Watson:     </th> <td>   1.526</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.019</td> <th>  Jarque-Bera (JB):  </th> <td>   9.237</td>
</tr>
<tr>
  <th>Skew:</th>          <td>-0.189</td> <th>  Prob(JB):          </th> <td> 0.00987</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 3.513</td> <th>  Cond. No.          </th> <td>1.23e+03</td>
</tr>
</table><br/><br/>Warnings:<br/>[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.<br/>[2] The condition number is large, 1.23e+03. This might indicate that there are<br/>strong multicollinearity or other numerical problems.




```python
#log_lot*rec removed
modeli = sm.OLS.from_formula("log_sell ~ log_lot+bdms+fb+sty+drv+rec+ffin+ghw+ca+gar+reg+log_lot*drv", data=df)
resi= modeli.fit()
print(resi.summary())
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>        <td>log_sell</td>     <th>  R-squared:         </th> <td>   0.689</td> 
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.682</td> 
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   98.19</td> 
</tr>
<tr>
  <th>Date:</th>             <td>Mon, 30 Nov 2020</td> <th>  Prob (F-statistic):</th> <td>1.83e-126</td>
</tr>
<tr>
  <th>Time:</th>                 <td>23:24:17</td>     <th>  Log-Likelihood:    </th> <td>  84.143</td> 
</tr>
<tr>
  <th>No. Observations:</th>      <td>   546</td>      <th>  AIC:               </th> <td>  -142.3</td> 
</tr>
<tr>
  <th>Df Residuals:</th>          <td>   533</td>      <th>  BIC:               </th> <td>  -86.35</td> 
</tr>
<tr>
  <th>Df Model:</th>              <td>    12</td>      <th>                     </th>     <td> </td>    
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>    
</tr>
</table>
<table class="simpletable">
<tr>
       <td></td>          <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>Intercept</th>   <td>    8.8348</td> <td>    0.630</td> <td>   14.026</td> <td> 0.000</td> <td>    7.597</td> <td>   10.072</td>
</tr>
<tr>
  <th>log_lot</th>     <td>    0.1696</td> <td>    0.077</td> <td>    2.194</td> <td> 0.029</td> <td>    0.018</td> <td>    0.321</td>
</tr>
<tr>
  <th>bdms</th>        <td>    0.0346</td> <td>    0.014</td> <td>    2.429</td> <td> 0.015</td> <td>    0.007</td> <td>    0.063</td>
</tr>
<tr>
  <th>fb</th>          <td>    0.1642</td> <td>    0.020</td> <td>    8.091</td> <td> 0.000</td> <td>    0.124</td> <td>    0.204</td>
</tr>
<tr>
  <th>sty</th>         <td>    0.0918</td> <td>    0.013</td> <td>    7.290</td> <td> 0.000</td> <td>    0.067</td> <td>    0.116</td>
</tr>
<tr>
  <th>drv</th>         <td>   -1.1161</td> <td>    0.667</td> <td>   -1.674</td> <td> 0.095</td> <td>   -2.426</td> <td>    0.193</td>
</tr>
<tr>
  <th>rec</th>         <td>    0.0561</td> <td>    0.026</td> <td>    2.157</td> <td> 0.031</td> <td>    0.005</td> <td>    0.107</td>
</tr>
<tr>
  <th>ffin</th>        <td>    0.1029</td> <td>    0.022</td> <td>    4.748</td> <td> 0.000</td> <td>    0.060</td> <td>    0.145</td>
</tr>
<tr>
  <th>ghw</th>         <td>    0.1790</td> <td>    0.044</td> <td>    4.087</td> <td> 0.000</td> <td>    0.093</td> <td>    0.265</td>
</tr>
<tr>
  <th>ca</th>          <td>    0.1658</td> <td>    0.021</td> <td>    7.787</td> <td> 0.000</td> <td>    0.124</td> <td>    0.208</td>
</tr>
<tr>
  <th>gar</th>         <td>    0.0468</td> <td>    0.011</td> <td>    4.083</td> <td> 0.000</td> <td>    0.024</td> <td>    0.069</td>
</tr>
<tr>
  <th>reg</th>         <td>    0.1307</td> <td>    0.023</td> <td>    5.777</td> <td> 0.000</td> <td>    0.086</td> <td>    0.175</td>
</tr>
<tr>
  <th>log_lot:drv</th> <td>    0.1500</td> <td>    0.081</td> <td>    1.841</td> <td> 0.066</td> <td>   -0.010</td> <td>    0.310</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td> 7.294</td> <th>  Durbin-Watson:     </th> <td>   1.527</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.026</td> <th>  Jarque-Bera (JB):  </th> <td>   8.228</td>
</tr>
<tr>
  <th>Skew:</th>          <td>-0.184</td> <th>  Prob(JB):          </th> <td>  0.0163</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 3.476</td> <th>  Cond. No.          </th> <td>1.22e+03</td>
</tr>
</table><br/><br/>Warnings:<br/>[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.<br/>[2] The condition number is large, 1.22e+03. This might indicate that there are<br/>strong multicollinearity or other numerical problems.



### Conclusion:

After ruling out interaction terms using the general to specific approach the final model should only include the interaction term: log of lot size* driveway dummy variable (see model i above).

# (g)
One may argue that some of the explanatory variables are endogenous and that there may be omitted variables. For example, the ‘condition’ of the house in terms of how it is maintained is not a variable (and difficult to measure) but will affect the house price. It will also affect, or be reflected in, some of the other variables, such as whether the house has an air conditioning (which is mostly in newer houses). If the condition of the house is missing, will the effect of air conditioning on the (log of the) sale price be over- or underestimated? (For this question no computer calculations are required.)

### Conclusion:
Since "condition of the home" is not included in the model, along with other factors which are correlated with the error term, epsilon, we conclude that house price (and log of house price) is endogenous, as well as several of the explanatory variables. The effect of air conditioning in this case will be overestimated as home condition will be included in the marginal effect of having air conditioning, overinflating our home price estimates.

# (h) 

Finally we analyze the predictive ability of the model. Consider again the model where the log of the sale price
of the house is the dependent variable and the explanatory variables are the log transformation of lot size, with
all other explanatory variables in their original form (and no interaction effects). Estimate the parameters of
the model using the first 400 observations. Make predictions on the log of the price and calculate the MAE for
the other 146 observations. How good is the predictive power of the model (relative to the variability in the
log of the price)?

#### Let "train" = first 400 observations of dataset (df) & let "test"= final 146 observations of dataset (df):


```python
train=df[0:400]
test=df[400:]
model_train = sm.OLS.from_formula("log_sell ~ log_lot+lot+bdms+fb+sty+drv+rec+ffin+ghw+ca+gar+reg", data=train)
res_train = model_train.fit()
print(res_train.summary())
```

                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:               log_sell   R-squared:                       0.671
    Model:                            OLS   Adj. R-squared:                  0.660
    Method:                 Least Squares   F-statistic:                     65.64
    Date:                Mon, 30 Nov 2020   Prob (F-statistic):           1.64e-85
    Time:                        23:25:01   Log-Likelihood:                 37.367
    No. Observations:                 400   AIC:                            -48.73
    Df Residuals:                     387   BIC:                             3.156
    Df Model:                          12                                         
    Covariance Type:            nonrobust                                         
    ==============================================================================
                     coef    std err          t      P>|t|      [0.025      0.975]
    ------------------------------------------------------------------------------
    Intercept      7.9123      0.879      9.006      0.000       6.185       9.640
    log_lot        0.2818      0.116      2.422      0.016       0.053       0.511
    lot         5.934e-06   2.06e-05      0.289      0.773   -3.45e-05    4.63e-05
    bdms           0.0376      0.017      2.153      0.032       0.003       0.072
    fb             0.1520      0.025      6.140      0.000       0.103       0.201
    sty            0.0885      0.018      4.853      0.000       0.053       0.124
    drv            0.0878      0.032      2.759      0.006       0.025       0.150
    rec            0.0560      0.034      1.634      0.103      -0.011       0.123
    ffin           0.1144      0.027      4.274      0.000       0.062       0.167
    ghw            0.1987      0.053      3.744      0.000       0.094       0.303
    ca             0.1780      0.027      6.520      0.000       0.124       0.232
    gar            0.0530      0.015      3.577      0.000       0.024       0.082
    reg            0.1503      0.042      3.553      0.000       0.067       0.233
    ==============================================================================
    Omnibus:                        0.901   Durbin-Watson:                   1.476
    Prob(Omnibus):                  0.637   Jarque-Bera (JB):                0.716
    Skew:                          -0.090   Prob(JB):                        0.699
    Kurtosis:                       3.103   Cond. No.                     4.23e+05
    ==============================================================================
    
    Warnings:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.
    [2] The condition number is large, 4.23e+05. This might indicate that there are
    strong multicollinearity or other numerical problems.



```python
model_test = sm.OLS.from_formula("log_sell ~ log_lot+lot+bdms+fb+sty+drv+rec+ffin+ghw+ca+gar+reg", data=test)
res_test = model_test.fit()
print(res_test.summary())
```

                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:               log_sell   R-squared:                       0.731
    Model:                            OLS   Adj. R-squared:                  0.707
    Method:                 Least Squares   F-statistic:                     30.13
    Date:                Mon, 30 Nov 2020   Prob (F-statistic):           3.41e-32
    Time:                        23:34:37   Log-Likelihood:                 70.558
    No. Observations:                 146   AIC:                            -115.1
    Df Residuals:                     133   BIC:                            -76.33
    Df Model:                          12                                         
    Covariance Type:            nonrobust                                         
    ==============================================================================
                     coef    std err          t      P>|t|      [0.025      0.975]
    ------------------------------------------------------------------------------
    Intercept      4.7505      0.972      4.890      0.000       2.829       6.672
    log_lot        0.6643      0.127      5.217      0.000       0.412       0.916
    lot        -7.859e-05    2.3e-05     -3.416      0.001      -0.000   -3.31e-05
    bdms           0.0232      0.024      0.951      0.343      -0.025       0.072
    fb             0.1955      0.034      5.691      0.000       0.128       0.263
    sty            0.0841      0.015      5.608      0.000       0.054       0.114
    drv            0.5375      0.113      4.736      0.000       0.313       0.762
    rec            0.0355      0.035      1.011      0.314      -0.034       0.105
    ffin           0.0787      0.033      2.354      0.020       0.013       0.145
    ghw            0.1028      0.072      1.431      0.155      -0.039       0.245
    ca             0.1145      0.030      3.757      0.000       0.054       0.175
    gar            0.0379      0.017      2.289      0.024       0.005       0.071
    reg            0.1083      0.031      3.511      0.001       0.047       0.169
    ==============================================================================
    Omnibus:                        1.734   Durbin-Watson:                   1.712
    Prob(Omnibus):                  0.420   Jarque-Bera (JB):                1.381
    Skew:                          -0.048   Prob(JB):                        0.501
    Kurtosis:                       3.467   Cond. No.                     4.70e+05
    ==============================================================================
    
    Warnings:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.
    [2] The condition number is large, 4.7e+05. This might indicate that there are
    strong multicollinearity or other numerical problems.



```python
mse_train=res_train.mse_model
print("Mean-Squared Error for train (n=400) data:", mse_train)
```

    Mean-Squared Error for train (n=400) data: 3.2955043626927334



```python
print(res_train.summary2())
```

                     Results: Ordinary least squares
    =================================================================
    Model:              OLS              Adj. R-squared:     0.660   
    Dependent Variable: log_sell         AIC:                -48.7330
    Date:               2020-12-01 00:39 BIC:                3.1560  
    No. Observations:   400              Log-Likelihood:     37.367  
    Df Model:           12               F-statistic:        65.64   
    Df Residuals:       387              Prob (F-statistic): 1.64e-85
    R-squared:          0.671            Scale:              0.050204
    -------------------------------------------------------------------
                 Coef.    Std.Err.     t      P>|t|     [0.025   0.975]
    -------------------------------------------------------------------
    Intercept    7.9123     0.8786   9.0057   0.0000    6.1849   9.6397
    log_lot      0.2818     0.1164   2.4216   0.0159    0.0530   0.5107
    lot          0.0000     0.0000   0.2887   0.7729   -0.0000   0.0000
    bdms         0.0376     0.0175   2.1528   0.0320    0.0033   0.0720
    fb           0.1520     0.0248   6.1399   0.0000    0.1033   0.2007
    sty          0.0885     0.0182   4.8528   0.0000    0.0527   0.1244
    drv          0.0878     0.0318   2.7595   0.0061    0.0253   0.1504
    rec          0.0560     0.0343   1.6338   0.1031   -0.0114   0.1235
    ffin         0.1144     0.0268   4.2736   0.0000    0.0618   0.1671
    ghw          0.1987     0.0531   3.7444   0.0002    0.0944   0.3031
    ca           0.1780     0.0273   6.5200   0.0000    0.1243   0.2317
    gar          0.0530     0.0148   3.5768   0.0004    0.0239   0.0821
    reg          0.1503     0.0423   3.5529   0.0004    0.0671   0.2335
    -----------------------------------------------------------------
    Omnibus:              0.901        Durbin-Watson:          1.476 
    Prob(Omnibus):        0.637        Jarque-Bera (JB):       0.716 
    Skew:                 -0.090       Prob(JB):               0.699 
    Kurtosis:             3.103        Condition No.:          422770
    =================================================================
    * The condition number is large (4e+05). This might indicate
    strong multicollinearity or other numerical problems.



```python
pred=res_train.predict(test)
print("Predicted Log of Home Price for Test Data:", pred)
```

    Predicted Log of Home Price for Test Data: 400    11.513638
    401    11.474370
    402    11.381008
    403    11.186940
    404    11.325803
    405    11.358523
    406    11.298190
    407    11.304389
    408    11.466191
    409    11.528824
    410    11.290817
    411    11.523928
    412    11.605500
    413    11.042359
    414    11.029946
    415    11.413355
    416    11.542744
    417    11.267786
    418    11.792698
    419    11.331574
    420    11.413486
    421    11.379393
    422    11.124759
    423    10.854466
    424    10.994233
    425    10.986283
    426    10.968728
    427    10.840954
    428    10.785195
    429    11.125551
             ...    
    516    11.404139
    517    11.474269
    518    11.362657
    519    11.190575
    520    11.662842
    521    11.583297
    522    11.527259
    523    11.402234
    524    11.527259
    525    11.613323
    526    11.494522
    527    11.354422
    528    11.489631
    529    11.348101
    530    11.446655
    531    11.439996
    532    11.203667
    533    11.290028
    534    11.138776
    535    11.425899
    536    11.436641
    537    11.126084
    538    11.373627
    539    11.183051
    540    11.338372
    541    11.422668
    542    11.436641
    543    11.545669
    544    11.368590
    545    11.160546
    Length: 146, dtype: float64



```python

```




    ['T',
     '_AXIS_ALIASES',
     '_AXIS_IALIASES',
     '_AXIS_LEN',
     '_AXIS_NAMES',
     '_AXIS_NUMBERS',
     '_AXIS_ORDERS',
     '_AXIS_REVERSED',
     '_AXIS_SLICEMAP',
     '__abs__',
     '__add__',
     '__and__',
     '__array__',
     '__array_prepare__',
     '__array_priority__',
     '__array_wrap__',
     '__bool__',
     '__bytes__',
     '__class__',
     '__contains__',
     '__copy__',
     '__deepcopy__',
     '__delattr__',
     '__delitem__',
     '__dict__',
     '__dir__',
     '__div__',
     '__divmod__',
     '__doc__',
     '__eq__',
     '__finalize__',
     '__float__',
     '__floordiv__',
     '__format__',
     '__ge__',
     '__getattr__',
     '__getattribute__',
     '__getitem__',
     '__getstate__',
     '__gt__',
     '__hash__',
     '__iadd__',
     '__iand__',
     '__ifloordiv__',
     '__imod__',
     '__imul__',
     '__init__',
     '__init_subclass__',
     '__int__',
     '__invert__',
     '__ior__',
     '__ipow__',
     '__isub__',
     '__iter__',
     '__itruediv__',
     '__ixor__',
     '__le__',
     '__len__',
     '__long__',
     '__lt__',
     '__matmul__',
     '__mod__',
     '__module__',
     '__mul__',
     '__ne__',
     '__neg__',
     '__new__',
     '__nonzero__',
     '__or__',
     '__pos__',
     '__pow__',
     '__radd__',
     '__rand__',
     '__rdiv__',
     '__rdivmod__',
     '__reduce__',
     '__reduce_ex__',
     '__repr__',
     '__rfloordiv__',
     '__rmatmul__',
     '__rmod__',
     '__rmul__',
     '__ror__',
     '__round__',
     '__rpow__',
     '__rsub__',
     '__rtruediv__',
     '__rxor__',
     '__setattr__',
     '__setitem__',
     '__setstate__',
     '__sizeof__',
     '__str__',
     '__sub__',
     '__subclasshook__',
     '__truediv__',
     '__unicode__',
     '__weakref__',
     '__xor__',
     '_accessors',
     '_add_numeric_operations',
     '_add_series_only_operations',
     '_add_series_or_dataframe_operations',
     '_agg_by_level',
     '_agg_examples_doc',
     '_agg_see_also_doc',
     '_aggregate',
     '_aggregate_multiple_funcs',
     '_align_frame',
     '_align_series',
     '_binop',
     '_box_item_values',
     '_builtin_table',
     '_can_hold_na',
     '_check_inplace_setting',
     '_check_is_chained_assignment_possible',
     '_check_label_or_level_ambiguity',
     '_check_percentile',
     '_check_setitem_copy',
     '_clear_item_cache',
     '_clip_with_one_bound',
     '_clip_with_scalar',
     '_consolidate',
     '_consolidate_inplace',
     '_construct_axes_dict',
     '_construct_axes_dict_for_slice',
     '_construct_axes_dict_from',
     '_construct_axes_from_arguments',
     '_constructor',
     '_constructor_expanddim',
     '_constructor_sliced',
     '_convert',
     '_create_indexer',
     '_cython_table',
     '_deprecations',
     '_dir_additions',
     '_dir_deletions',
     '_drop_axis',
     '_drop_labels_or_levels',
     '_expand_axes',
     '_find_valid_index',
     '_formatting_values',
     '_from_axes',
     '_get_axis',
     '_get_axis_name',
     '_get_axis_number',
     '_get_axis_resolvers',
     '_get_block_manager_axis',
     '_get_bool_data',
     '_get_cacher',
     '_get_index_resolvers',
     '_get_item_cache',
     '_get_label_or_level_values',
     '_get_numeric_data',
     '_get_value',
     '_get_values',
     '_get_values_tuple',
     '_get_with',
     '_gotitem',
     '_iget_item_cache',
     '_index',
     '_indexed_same',
     '_info_axis',
     '_info_axis_name',
     '_info_axis_number',
     '_init_dict',
     '_init_mgr',
     '_internal_names',
     '_internal_names_set',
     '_is_builtin_func',
     '_is_cached',
     '_is_copy',
     '_is_cython_func',
     '_is_datelike_mixed_type',
     '_is_homogeneous_type',
     '_is_label_or_level_reference',
     '_is_label_reference',
     '_is_level_reference',
     '_is_mixed_type',
     '_is_numeric_mixed_type',
     '_is_view',
     '_ix',
     '_ixs',
     '_map_values',
     '_maybe_cache_changed',
     '_maybe_update_cacher',
     '_metadata',
     '_ndarray_values',
     '_needs_reindex_multi',
     '_obj_with_exclusions',
     '_protect_consolidate',
     '_reduce',
     '_reindex_axes',
     '_reindex_indexer',
     '_reindex_multi',
     '_reindex_with_indexers',
     '_repr_data_resource_',
     '_repr_latex_',
     '_reset_cache',
     '_reset_cacher',
     '_selected_obj',
     '_selection',
     '_selection_list',
     '_selection_name',
     '_set_as_cached',
     '_set_axis',
     '_set_axis_name',
     '_set_is_copy',
     '_set_item',
     '_set_labels',
     '_set_name',
     '_set_subtyp',
     '_set_value',
     '_set_values',
     '_set_with',
     '_set_with_engine',
     '_setup_axes',
     '_shallow_copy',
     '_slice',
     '_stat_axis',
     '_stat_axis_name',
     '_stat_axis_number',
     '_take',
     '_to_dict_of_blocks',
     '_try_aggregate_string_function',
     '_typ',
     '_unpickle_series_compat',
     '_update_inplace',
     '_validate_dtype',
     '_values',
     '_where',
     '_xs',
     'abs',
     'add',
     'add_prefix',
     'add_suffix',
     'agg',
     'aggregate',
     'align',
     'all',
     'any',
     'append',
     'apply',
     'argmax',
     'argmin',
     'argsort',
     'array',
     'as_matrix',
     'asfreq',
     'asof',
     'astype',
     'at',
     'at_time',
     'autocorr',
     'axes',
     'base',
     'between',
     'between_time',
     'bfill',
     'bool',
     'clip',
     'clip_lower',
     'clip_upper',
     'combine',
     'combine_first',
     'compound',
     'compress',
     'copy',
     'corr',
     'count',
     'cov',
     'cummax',
     'cummin',
     'cumprod',
     'cumsum',
     'data',
     'describe',
     'diff',
     'div',
     'divide',
     'divmod',
     'dot',
     'drop',
     'drop_duplicates',
     'droplevel',
     'dropna',
     'dtype',
     'dtypes',
     'duplicated',
     'empty',
     'eq',
     'equals',
     'ewm',
     'expanding',
     'factorize',
     'ffill',
     'fillna',
     'filter',
     'first',
     'first_valid_index',
     'flags',
     'floordiv',
     'from_array',
     'ftype',
     'ftypes',
     'ge',
     'get',
     'get_dtype_counts',
     'get_ftype_counts',
     'get_values',
     'groupby',
     'gt',
     'hasnans',
     'head',
     'hist',
     'iat',
     'idxmax',
     'idxmin',
     'iloc',
     'imag',
     'index',
     'infer_objects',
     'interpolate',
     'is_monotonic',
     'is_monotonic_decreasing',
     'is_monotonic_increasing',
     'is_unique',
     'isin',
     'isna',
     'isnull',
     'item',
     'items',
     'itemsize',
     'iteritems',
     'ix',
     'keys',
     'kurt',
     'kurtosis',
     'last',
     'last_valid_index',
     'le',
     'loc',
     'lt',
     'mad',
     'map',
     'mask',
     'max',
     'mean',
     'median',
     'memory_usage',
     'min',
     'mod',
     'mode',
     'mul',
     'multiply',
     'name',
     'nbytes',
     'ndim',
     'ne',
     'nlargest',
     'nonzero',
     'notna',
     'notnull',
     'nsmallest',
     'nunique',
     'pct_change',
     'pipe',
     'plot',
     'pop',
     'pow',
     'prod',
     'product',
     'ptp',
     'put',
     'quantile',
     'radd',
     'rank',
     'ravel',
     'rdiv',
     'rdivmod',
     'real',
     'reindex',
     'reindex_axis',
     'reindex_like',
     'rename',
     'rename_axis',
     'reorder_levels',
     'repeat',
     'replace',
     'resample',
     'reset_index',
     'rfloordiv',
     'rmod',
     'rmul',
     'rolling',
     'round',
     'rpow',
     'rsub',
     'rtruediv',
     'sample',
     'searchsorted',
     'select',
     'sem',
     'set_axis',
     'shape',
     'shift',
     'size',
     'skew',
     'slice_shift',
     'sort_index',
     'sort_values',
     'squeeze',
     'std',
     'strides',
     'sub',
     'subtract',
     'sum',
     'swapaxes',
     'swaplevel',
     'tail',
     'take',
     'timetuple',
     'to_clipboard',
     'to_csv',
     'to_dense',
     'to_dict',
     'to_excel',
     'to_frame',
     'to_hdf',
     'to_json',
     'to_latex',
     'to_list',
     'to_msgpack',
     'to_numpy',
     'to_period',
     'to_pickle',
     'to_sparse',
     'to_sql',
     'to_string',
     'to_timestamp',
     'to_xarray',
     'transform',
     'transpose',
     'truediv',
     'truncate',
     'tshift',
     'tz_convert',
     'tz_localize',
     'unique',
     'unstack',
     'update',
     'value_counts',
     'values',
     'var',
     'view',
     'where',
     'xs']




```python
plt.plot(pred, "--m")
plt.plot(test["log_sell"])
plt.title("Actual(A) vs. Predicted(P) Home Prices")
plt.ylabel("LOG(Sell Price)")
plt.xlabel("Observation")
plt.legend("PA")
plt.show()
```


![png](output_45_0.png)


### Conclusion:
As you can see from the performance metrics above (including mse, mae, r-squared, and adjusted r-squared) and visually by observing the predicted values on the "test" data (last 146 observations) versus the actual values, our model does have some predictive ability, albeit not perfect. There are still many improvements that could be made to improve the model's predictive accuracy.

